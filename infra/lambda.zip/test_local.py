import os
import json
from app import lambda_handler

# 1. Mock the Lambda Context object (required for context.aws_request_id)
class MockContext:
    def __init__(self):
        self.aws_request_id = "LOCAL-TEST-ID-123"

# 2. Define a fake event (what API Gateway would normally send)
test_event = {
    "body": json.dumps({
        "ingredients": ["eggs", "spinach", "feta cheese"]
    })
}

# 3. Execute the handler
if __name__ == "__main__":
    # Ensure your API Key is available to the script
    if not os.environ.get("GEMINI_API_KEY"):
        print("❌ ERROR: GEMINI_API_KEY not found in environment variables.")
    else:
        print("👨‍🍳 Starting local Chef test...")
        context = MockContext()
        response = lambda_handler(test_event, context)
        
        print(f"\nResponse Status Code: {response['statusCode']}")
        print("Response Body:")
        print(json.dumps(json.loads(response['body']), indent=4))